package Kiosk;

import java.awt.*;
import javax.swing.*;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Banner extends JPanel{
	public Banner(){
		setBackground(Color.LIGHT_GRAY);
		ImageIcon AD_image = new ImageIcon("src/Kosk_201810459/images/3.jpg");
		JLabel ad = new JLabel(AD_image);
		add(ad);
	}
}
