package Kiosk;

import java.awt.Frame;

public class main {

	public static void main(String[] args) {
		new Kiosk_JFrame();
	}

}
