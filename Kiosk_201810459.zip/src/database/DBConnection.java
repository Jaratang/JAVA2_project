package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConnection {
	private Connection conn;
	private Statement st;
	private ResultSet rs;
	
	public DBConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/kiosk","root","1234");
			st = conn.createStatement();
		}catch(Exception e) {
			System.out.println("�����ͺ��̽� ���� ����" + e.getMessage());
		}
	}
}
