public class Kiosk_Main {
	public static void main(String[] args) {
		new Kiosk_JFrame();
	}
}