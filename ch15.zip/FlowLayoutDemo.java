package ch15;

import java.awt.*;
import javax.swing.*;

public class FlowLayoutDemo extends JFrame{
	FlowLayoutDemo(){
		setTitle("�÷ο� ���̾ƿ�!");
		
		JPanel p = new JPanel(new FlowLayout()); 
		p.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);	//�� -> �� ������ ��ġ
		JButton b1 = new JButton("B 1");
		JButton b2 = new JButton("B 2");
		JButton b3 = new JButton("B 3");
		JButton b4 = new JButton("B 4");
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.add(b4);
		add(p);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,100);
		setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FlowLayoutDemo();
	}

}
