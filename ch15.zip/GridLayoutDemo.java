package ch15;

import java.awt.*;
import javax.swing.*;

public class GridLayoutDemo extends JFrame{
	GridLayoutDemo(){
		setTitle("�׸��� ���̾ƿ�");
		setLayout(new GridLayout(0,2));
		
		add(new JButton("B 1"));
		add(new JButton("B 2"));
		add(new JButton("B 3"));
		add(new JButton("B 4"));
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,100);
		setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GridLayoutDemo();
	}

}
