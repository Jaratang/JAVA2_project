package ch16;

import java.awt.event.*;
import javax.swing.*;

public class HelloEventDemo extends JFrame{
	HelloEventDemo(){
		setTitle("Ŭ�� �̺�Ʈ");
		ActionListener l = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("��ư�� Ŭ���߽��ϴ�.");
			}
		};
		
		JButton b = new JButton("��ư");
		b.addActionListener(l);
		
		add(b);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(100,100);
		setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new HelloEventDemo();
	}

}
