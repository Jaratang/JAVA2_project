package ch16;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MouseMotionAdapterDemo extends JFrame{
	MouseMotionAdapterDemo(){
		setTitle("���콺 �̵� �����");
		
		JLabel label = new JLabel("�����̴� ���̺�");
		label.setForeground(Color.RED);
		add(label);
		
		addMouseMotionListener(new MyMouseMotionAdapter(label));
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,100);
		setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MouseMotionAdapterDemo();
	}
}

class MyMouseMotionAdapter extends MouseMotionAdapter{
	JLabel label;
	
	public MyMouseMotionAdapter(JLabel label) {
		this.label = label;
	}
	
	public void mouseMoved(MouseEvent e) {
		label.setLocation(e.getX(), e.getY() - 50);
	}
}
